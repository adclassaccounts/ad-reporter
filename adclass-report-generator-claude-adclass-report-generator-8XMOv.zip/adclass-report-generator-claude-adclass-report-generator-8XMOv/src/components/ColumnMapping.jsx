import { useState, useEffect } from 'react';
import { autoDetectColumns } from '../utils/fileParser';

const FIELD_CONFIG = {
  adName: { label: 'Ad Name', required: true, description: 'The name or title of your ad' },
  spend: { label: 'Amount Spent', required: true, description: 'How much was spent on this ad' },
  leads: { label: 'Leads', required: true, description: 'Number of leads or conversions' },
  cpl: { label: 'Cost Per Lead', required: false, description: 'CPL (auto-calculated if empty)' },
  reach: { label: 'Reach', required: false, description: 'Unique people who saw the ad' },
  impressions: { label: 'Impressions', required: false, description: 'Total ad views' },
  status: { label: 'Status', required: false, description: 'Active/Inactive status' },
};

const ColumnMapping = ({ fileData, onMappingComplete, onBack }) => {
  const [mapping, setMapping] = useState({});
  const [errors, setErrors] = useState([]);

  useEffect(() => {
    const detected = autoDetectColumns(fileData.columns);
    setMapping(detected);
  }, [fileData.columns]);

  const handleMappingChange = (field, value) => {
    setMapping(prev => ({
      ...prev,
      [field]: value || null,
    }));
    setErrors([]);
  };

  const validateMapping = () => {
    const newErrors = [];
    Object.entries(FIELD_CONFIG).forEach(([field, config]) => {
      if (config.required && !mapping[field]) {
        newErrors.push(`${config.label} is required`);
      }
    });
    return newErrors;
  };

  const handleContinue = () => {
    const validationErrors = validateMapping();
    if (validationErrors.length > 0) {
      setErrors(validationErrors);
      return;
    }
    onMappingComplete(mapping);
  };

  const getUnmappedColumns = (currentField) => {
    const mappedColumns = Object.entries(mapping)
      .filter(([field]) => field !== currentField)
      .map(([, col]) => col)
      .filter(Boolean);
    return fileData.columns.filter(col => !mappedColumns.includes(col));
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-gold transition-colors mb-4"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </button>
          <h1 className="text-2xl font-bold text-white mb-2">Map Your Columns</h1>
          <p className="text-gray-400">
            We've auto-detected some columns. Please verify and adjust if needed.
          </p>
        </div>

        {/* File Info */}
        <div className="bg-card rounded-xl p-4 mb-6 flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-gold/20 flex items-center justify-center">
            <svg className="w-5 h-5 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-white font-medium">{fileData.fileName}</p>
            <p className="text-sm text-gray-400">{fileData.rowCount} rows detected</p>
          </div>
          <span className="px-3 py-1 bg-success/20 text-success text-sm rounded-full">
            Loaded
          </span>
        </div>

        {/* Column Mapping */}
        <div className="bg-card rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Column Mapping</h2>

          <div className="space-y-4">
            {Object.entries(FIELD_CONFIG).map(([field, config]) => (
              <div key={field} className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-start">
                <div>
                  <label className="block text-sm font-medium text-white">
                    {config.label}
                    {config.required && <span className="text-danger ml-1">*</span>}
                  </label>
                  <p className="text-xs text-gray-500 mt-0.5">{config.description}</p>
                </div>
                <select
                  value={mapping[field] || ''}
                  onChange={(e) => handleMappingChange(field, e.target.value)}
                  className={`
                    w-full px-3 py-2 rounded-lg bg-dark border text-white
                    focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent
                    ${mapping[field] ? 'border-success' : 'border-gray-600'}
                  `}
                >
                  <option value="">-- Select Column --</option>
                  {getUnmappedColumns(field).map(col => (
                    <option key={col} value={col}>{col}</option>
                  ))}
                  {mapping[field] && !getUnmappedColumns(field).includes(mapping[field]) && (
                    <option value={mapping[field]}>{mapping[field]}</option>
                  )}
                </select>
              </div>
            ))}
          </div>
        </div>

        {/* Data Preview */}
        <div className="bg-card rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Data Preview</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-700">
                  {fileData.columns.slice(0, 5).map(col => (
                    <th key={col} className="text-left py-2 px-3 text-gray-400 font-medium">
                      {col}
                    </th>
                  ))}
                  {fileData.columns.length > 5 && (
                    <th className="text-left py-2 px-3 text-gray-400 font-medium">...</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {fileData.data.slice(0, 3).map((row, i) => (
                  <tr key={i} className="border-b border-gray-800">
                    {fileData.columns.slice(0, 5).map(col => (
                      <td key={col} className="py-2 px-3 text-gray-300 truncate max-w-[150px]">
                        {row[col] !== undefined ? String(row[col]) : ''}
                      </td>
                    ))}
                    {fileData.columns.length > 5 && (
                      <td className="py-2 px-3 text-gray-500">...</td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Errors */}
        {errors.length > 0 && (
          <div className="mb-6 p-4 rounded-lg bg-danger/20 border border-danger">
            <p className="text-danger font-medium mb-2">Please fix the following:</p>
            <ul className="list-disc list-inside text-danger/80 text-sm">
              {errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          className="w-full py-3 px-6 bg-gold hover:bg-gold-light text-dark font-semibold rounded-xl transition-colors"
        >
          Continue to Configuration
        </button>
      </div>
    </div>
  );
};

export default ColumnMapping;
