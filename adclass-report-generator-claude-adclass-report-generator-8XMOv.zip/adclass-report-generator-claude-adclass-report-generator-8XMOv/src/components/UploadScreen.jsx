import { useState, useCallback } from 'react';
import { parseFile } from '../utils/fileParser';

const UploadScreen = ({ onFileUpload }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(async (e) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await processFile(files[0]);
    }
  }, []);

  const handleFileSelect = useCallback(async (e) => {
    const files = e.target.files;
    if (files.length > 0) {
      await processFile(files[0]);
    }
  }, []);

  const processFile = async (file) => {
    setIsLoading(true);
    setError(null);

    try {
      const result = await parseFile(file);
      if (result.data.length === 0) {
        setError('The file appears to be empty or has no valid data rows.');
        setIsLoading(false);
        return;
      }
      onFileUpload({
        fileName: file.name,
        ...result,
      });
    } catch (err) {
      setError(err.message || 'Failed to parse file. Please check the format.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      {/* Logo */}
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-wider">
          <span className="text-gold">AD</span>
          <span className="text-white">CLASS</span>
        </h1>
        <p className="text-gray-400 mt-2">Ad Performance Report Generator</p>
      </div>

      {/* Upload Zone */}
      <div
        className={`
          relative w-full max-w-xl p-12 rounded-2xl border-2 border-dashed
          transition-all duration-200 cursor-pointer
          ${isDragging
            ? 'border-gold bg-gold/10'
            : 'border-gray-600 bg-card hover:border-gold hover:bg-card-hover'
          }
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => document.getElementById('fileInput').click()}
      >
        <input
          type="file"
          id="fileInput"
          className="hidden"
          accept=".csv,.xlsx,.xls"
          onChange={handleFileSelect}
        />

        <div className="flex flex-col items-center text-center">
          {isLoading ? (
            <>
              <div className="w-16 h-16 mb-4 rounded-full border-4 border-gold border-t-transparent animate-spin" />
              <p className="text-lg text-gray-300">Processing file...</p>
            </>
          ) : (
            <>
              <div className="w-16 h-16 mb-4 flex items-center justify-center rounded-full bg-gold/20">
                <svg
                  className="w-8 h-8 text-gold"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <p className="text-lg text-white font-medium mb-2">
                Drop your ad data here
              </p>
              <p className="text-gray-400 mb-4">or click to browse</p>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span className="px-2 py-1 bg-gray-700 rounded">CSV</span>
                <span className="px-2 py-1 bg-gray-700 rounded">XLSX</span>
                <span className="px-2 py-1 bg-gray-700 rounded">XLS</span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-4 p-4 rounded-lg bg-danger/20 border border-danger text-danger max-w-xl w-full">
          <div className="flex items-start gap-3">
            <svg className="w-5 h-5 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p>{error}</p>
          </div>
        </div>
      )}

      {/* Info */}
      <p className="mt-8 text-sm text-gray-500 text-center max-w-md">
        Upload your Facebook Ads, Google Ads, or other advertising platform data.
        We'll help you create a professional report.
      </p>
    </div>
  );
};

export default UploadScreen;
