import { useState, useEffect, useMemo } from 'react';
import { processData, calculateTotals, getCPLTier, getTopPerformers, getNeedsOptimization } from '../utils/fileParser';
import { generateReportHTML, downloadReport } from '../utils/reportGenerator';

const formatCurrency = (value) => {
  if (value === null || value === undefined) return 'N/A';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
};

const formatNumber = (value) => {
  if (value === null || value === undefined) return 'N/A';
  return new Intl.NumberFormat('en-US').format(Math.round(value));
};

const ReportPreview = ({ fileData, columnMapping, reportConfig, onBack, onStartOver }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'cpl', direction: 'asc' });

  const processedData = useMemo(() => {
    return processData(fileData.data, columnMapping);
  }, [fileData.data, columnMapping]);

  const totals = useMemo(() => {
    return calculateTotals(processedData);
  }, [processedData]);

  const topPerformers = useMemo(() => {
    return getTopPerformers(processedData, 5);
  }, [processedData]);

  const needsOptimization = useMemo(() => {
    return getNeedsOptimization(processedData, 5);
  }, [processedData]);

  const sortedData = useMemo(() => {
    const sorted = [...processedData].sort((a, b) => {
      let aVal = a[sortConfig.key];
      let bVal = b[sortConfig.key];

      if (aVal === null || aVal === undefined) aVal = sortConfig.direction === 'asc' ? Infinity : -Infinity;
      if (bVal === null || bVal === undefined) bVal = sortConfig.direction === 'asc' ? Infinity : -Infinity;

      if (typeof aVal === 'string') {
        return sortConfig.direction === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }

      return sortConfig.direction === 'asc' ? aVal - bVal : bVal - aVal;
    });
    return sorted;
  }, [processedData, sortConfig]);

  const maxCPL = useMemo(() => {
    return Math.max(...processedData.filter(d => d.cpl !== null).map(d => d.cpl), 1);
  }, [processedData]);

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const handleDownload = () => {
    const html = generateReportHTML({
      data: processedData,
      reportTitle: reportConfig.reportTitle,
      clientName: reportConfig.clientName,
      dateRange: reportConfig.dateRange,
      thresholds: reportConfig.thresholds,
      generatedDate: new Date().toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      }),
    });
    downloadReport(html, reportConfig.clientName, reportConfig.dateRange);
  };

  const getTierColor = (tier) => {
    const colors = {
      excellent: 'text-success',
      good: 'text-gold',
      average: 'text-warning',
      poor: 'text-danger',
      unknown: 'text-gray-500',
    };
    return colors[tier] || colors.unknown;
  };

  const getTierBgColor = (tier) => {
    const colors = {
      excellent: 'bg-success',
      good: 'bg-gold',
      average: 'bg-warning',
      poor: 'bg-danger',
      unknown: 'bg-gray-500',
    };
    return colors[tier] || colors.unknown;
  };

  const SortIcon = ({ columnKey }) => {
    if (sortConfig.key !== columnKey) return null;
    return (
      <span className="ml-1">
        {sortConfig.direction === 'asc' ? '\u2191' : '\u2193'}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-dark">
      {/* Top Bar */}
      <div className="sticky top-0 z-10 bg-dark/95 backdrop-blur border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-gold transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Config
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={onStartOver}
              className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
            >
              Start Over
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 px-5 py-2 bg-gold hover:bg-gold-light text-dark font-semibold rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Download Report
            </button>
          </div>
        </div>
      </div>

      {/* Report Preview */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-10 pb-8 border-b border-gray-800">
          <h1 className="text-3xl font-bold tracking-wider mb-4">
            <span className="text-gold">AD</span>
            <span className="text-white">CLASS</span>
          </h1>
          <h2 className="text-2xl font-bold text-white mb-2">{reportConfig.reportTitle}</h2>
          <p className="text-gold text-lg mb-3">{reportConfig.clientName}</p>
          <p className="text-gray-400 text-sm">
            Report Period: {reportConfig.dateRange}
          </p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <div className="bg-gradient-to-br from-gold to-gold-dark rounded-xl p-5 text-center">
            <p className="text-xs font-semibold uppercase tracking-wide text-white/80 mb-2">Blended CPL</p>
            <p className="text-2xl font-bold text-white">{formatCurrency(totals.blendedCPL)}</p>
          </div>
          <div className="bg-card rounded-xl p-5 text-center">
            <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">Total Spend</p>
            <p className="text-2xl font-bold text-white">{formatCurrency(totals.spend)}</p>
          </div>
          <div className="bg-card rounded-xl p-5 text-center">
            <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">Total Leads</p>
            <p className="text-2xl font-bold text-white">{formatNumber(totals.leads)}</p>
          </div>
          <div className="bg-card rounded-xl p-5 text-center">
            <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">Total Reach</p>
            <p className="text-2xl font-bold text-white">{formatNumber(totals.reach)}</p>
          </div>
          <div className="bg-card rounded-xl p-5 text-center col-span-2 md:col-span-1">
            <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">Impressions</p>
            <p className="text-2xl font-bold text-white">{formatNumber(totals.impressions)}</p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Top Performers */}
          <div className="bg-card rounded-xl p-6">
            <h3 className="text-success font-semibold flex items-center gap-2 mb-4">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Top Performers
            </h3>
            <div className="space-y-3">
              {topPerformers.map((ad, i) => {
                const tier = getCPLTier(ad.cpl, reportConfig.thresholds);
                return (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-gray-800 last:border-0">
                    <span className="text-gray-300 truncate max-w-[200px]" title={ad.adName}>
                      {ad.adName}
                    </span>
                    <span className={`font-semibold ${getTierColor(tier)}`}>
                      {formatCurrency(ad.cpl)}
                    </span>
                  </div>
                );
              })}
              {topPerformers.length === 0 && (
                <p className="text-gray-500 text-sm">No data available</p>
              )}
            </div>
          </div>

          {/* Needs Optimization */}
          <div className="bg-card rounded-xl p-6">
            <h3 className="text-warning font-semibold flex items-center gap-2 mb-4">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Needs Optimization
            </h3>
            <div className="space-y-3">
              {needsOptimization.map((ad, i) => {
                const tier = getCPLTier(ad.cpl, reportConfig.thresholds);
                return (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-gray-800 last:border-0">
                    <span className="text-gray-300 truncate max-w-[200px]" title={ad.adName}>
                      {ad.adName}
                    </span>
                    <span className={`font-semibold ${getTierColor(tier)}`}>
                      {formatCurrency(ad.cpl)}
                    </span>
                  </div>
                );
              })}
              {needsOptimization.length === 0 && (
                <p className="text-gray-500 text-sm">No data available</p>
              )}
            </div>
          </div>
        </div>

        {/* Data Table */}
        <div className="bg-card rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-800">
            <h3 className="text-lg font-semibold text-white">All Ad Performance</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-dark/50">
                  <th
                    onClick={() => handleSort('adName')}
                    className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    Ad Name <SortIcon columnKey="adName" />
                  </th>
                  <th
                    onClick={() => handleSort('spend')}
                    className="text-right py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    Spend <SortIcon columnKey="spend" />
                  </th>
                  <th
                    onClick={() => handleSort('leads')}
                    className="text-right py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    Leads <SortIcon columnKey="leads" />
                  </th>
                  <th
                    onClick={() => handleSort('cpl')}
                    className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    CPL <SortIcon columnKey="cpl" />
                  </th>
                  <th
                    onClick={() => handleSort('reach')}
                    className="text-right py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    Reach <SortIcon columnKey="reach" />
                  </th>
                  <th
                    onClick={() => handleSort('impressions')}
                    className="text-right py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    Impressions <SortIcon columnKey="impressions" />
                  </th>
                  <th
                    onClick={() => handleSort('status')}
                    className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wide text-gray-400 cursor-pointer hover:text-gold"
                  >
                    Status <SortIcon columnKey="status" />
                  </th>
                </tr>
              </thead>
              <tbody>
                {sortedData.map((row, i) => {
                  const tier = getCPLTier(row.cpl, reportConfig.thresholds);
                  const barWidth = row.cpl !== null ? Math.min((row.cpl / maxCPL) * 100, 100) : 0;
                  const isActive = row.status && ['active', 'running', 'enabled', 'live'].includes(String(row.status).toLowerCase().trim());

                  return (
                    <tr key={i} className="border-b border-gray-800 hover:bg-dark/30">
                      <td className="py-3 px-4 text-white max-w-[250px] truncate" title={row.adName}>
                        {row.adName}
                      </td>
                      <td className="py-3 px-4 text-right text-gray-300">
                        {formatCurrency(row.spend)}
                      </td>
                      <td className="py-3 px-4 text-right text-gray-300">
                        {formatNumber(row.leads)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <span className={`font-semibold min-w-[70px] ${getTierColor(tier)}`}>
                            {formatCurrency(row.cpl)}
                          </span>
                          <div className="flex-1 max-w-[80px] h-1.5 bg-gray-700 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${getTierBgColor(tier)}`}
                              style={{ width: `${barWidth}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right text-gray-300">
                        {formatNumber(row.reach)}
                      </td>
                      <td className="py-3 px-4 text-right text-gray-300">
                        {formatNumber(row.impressions)}
                      </td>
                      <td className="py-3 px-4">
                        {row.status && (
                          <span className={`
                            inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium
                            ${isActive ? 'bg-success/20 text-success' : 'bg-gray-600/20 text-gray-400'}
                          `}>
                            {isActive ? 'Active' : 'Inactive'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-10 pt-8 border-t border-gray-800">
          <p className="text-xl font-bold tracking-wider mb-2">
            <span className="text-gold">AD</span>
            <span className="text-gray-400">CLASS</span>
          </p>
          <p className="text-gray-500 text-sm">
            Report prepared by AdClass | info@adclass.com
          </p>
        </div>
      </div>
    </div>
  );
};

export default ReportPreview;
