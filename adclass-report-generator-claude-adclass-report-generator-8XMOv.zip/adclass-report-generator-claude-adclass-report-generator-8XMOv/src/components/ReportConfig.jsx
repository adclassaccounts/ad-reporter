import { useState } from 'react';

const DEFAULT_THRESHOLDS = {
  excellent: 40,
  good: 80,
  average: 150,
};

const ReportConfig = ({ onConfigComplete, onBack }) => {
  const [config, setConfig] = useState({
    reportTitle: 'Ad Performance Report',
    clientName: 'Client',
    dateRange: getCurrentMonthRange(),
    thresholds: { ...DEFAULT_THRESHOLDS },
  });

  const [errors, setErrors] = useState({});

  function getCurrentMonthRange() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${formatDate(firstDay)} - ${formatDate(lastDay)}`;
  }

  function formatDate(date) {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  }

  const handleChange = (field, value) => {
    setConfig(prev => ({
      ...prev,
      [field]: value,
    }));
    setErrors(prev => ({ ...prev, [field]: null }));
  };

  const handleThresholdChange = (tier, value) => {
    const numValue = parseFloat(value) || 0;
    setConfig(prev => ({
      ...prev,
      thresholds: {
        ...prev.thresholds,
        [tier]: numValue,
      },
    }));
  };

  const validateConfig = () => {
    const newErrors = {};
    if (!config.reportTitle.trim()) {
      newErrors.reportTitle = 'Report title is required';
    }
    if (!config.clientName.trim()) {
      newErrors.clientName = 'Client name is required';
    }
    if (!config.dateRange.trim()) {
      newErrors.dateRange = 'Date range is required';
    }
    return newErrors;
  };

  const handleContinue = () => {
    const validationErrors = validateConfig();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    onConfigComplete(config);
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-400 hover:text-gold transition-colors mb-4"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </button>
          <h1 className="text-2xl font-bold text-white mb-2">Configure Report</h1>
          <p className="text-gray-400">
            Customize your report settings before generating.
          </p>
        </div>

        {/* Basic Info */}
        <div className="bg-card rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Report Details</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Report Title
              </label>
              <input
                type="text"
                value={config.reportTitle}
                onChange={(e) => handleChange('reportTitle', e.target.value)}
                className={`
                  w-full px-4 py-2.5 rounded-lg bg-dark border text-white
                  focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent
                  ${errors.reportTitle ? 'border-danger' : 'border-gray-600'}
                `}
                placeholder="Ad Performance Report"
              />
              {errors.reportTitle && (
                <p className="mt-1 text-sm text-danger">{errors.reportTitle}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Client Name
              </label>
              <input
                type="text"
                value={config.clientName}
                onChange={(e) => handleChange('clientName', e.target.value)}
                className={`
                  w-full px-4 py-2.5 rounded-lg bg-dark border text-white
                  focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent
                  ${errors.clientName ? 'border-danger' : 'border-gray-600'}
                `}
                placeholder="Client Name"
              />
              {errors.clientName && (
                <p className="mt-1 text-sm text-danger">{errors.clientName}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                Date Range
              </label>
              <input
                type="text"
                value={config.dateRange}
                onChange={(e) => handleChange('dateRange', e.target.value)}
                className={`
                  w-full px-4 py-2.5 rounded-lg bg-dark border text-white
                  focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent
                  ${errors.dateRange ? 'border-danger' : 'border-gray-600'}
                `}
                placeholder="Jan 1, 2024 - Jan 31, 2024"
              />
              {errors.dateRange && (
                <p className="mt-1 text-sm text-danger">{errors.dateRange}</p>
              )}
            </div>
          </div>
        </div>

        {/* CPL Thresholds */}
        <div className="bg-card rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-2">CPL Thresholds</h2>
          <p className="text-sm text-gray-400 mb-4">
            Define cost-per-lead ranges for performance classification.
          </p>

          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 w-32">
                <div className="w-3 h-3 rounded-full bg-success" />
                <span className="text-sm text-white">Excellent</span>
              </div>
              <div className="flex items-center gap-2 flex-1">
                <span className="text-gray-400">&lt;</span>
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                  <input
                    type="number"
                    value={config.thresholds.excellent}
                    onChange={(e) => handleThresholdChange('excellent', e.target.value)}
                    className="w-full pl-7 pr-4 py-2 rounded-lg bg-dark border border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                    min="0"
                    step="1"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 w-32">
                <div className="w-3 h-3 rounded-full bg-gold" />
                <span className="text-sm text-white">Good</span>
              </div>
              <div className="flex items-center gap-2 flex-1">
                <span className="text-gray-400">&lt;</span>
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                  <input
                    type="number"
                    value={config.thresholds.good}
                    onChange={(e) => handleThresholdChange('good', e.target.value)}
                    className="w-full pl-7 pr-4 py-2 rounded-lg bg-dark border border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                    min="0"
                    step="1"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 w-32">
                <div className="w-3 h-3 rounded-full bg-warning" />
                <span className="text-sm text-white">Average</span>
              </div>
              <div className="flex items-center gap-2 flex-1">
                <span className="text-gray-400">&lt;</span>
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                  <input
                    type="number"
                    value={config.thresholds.average}
                    onChange={(e) => handleThresholdChange('average', e.target.value)}
                    className="w-full pl-7 pr-4 py-2 rounded-lg bg-dark border border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                    min="0"
                    step="1"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 w-32">
                <div className="w-3 h-3 rounded-full bg-danger" />
                <span className="text-sm text-white">Poor</span>
              </div>
              <span className="text-gray-400 text-sm">
                &ge; ${config.thresholds.average}
              </span>
            </div>
          </div>
        </div>

        {/* Preview Legend */}
        <div className="bg-card rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Performance Legend</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded bg-success" />
              <span className="text-gray-300">Excellent: &lt;${config.thresholds.excellent}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded bg-gold" />
              <span className="text-gray-300">Good: ${config.thresholds.excellent}-${config.thresholds.good - 1}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded bg-warning" />
              <span className="text-gray-300">Average: ${config.thresholds.good}-${config.thresholds.average - 1}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded bg-danger" />
              <span className="text-gray-300">Poor: &ge;${config.thresholds.average}</span>
            </div>
          </div>
        </div>

        {/* Continue Button */}
        <button
          onClick={handleContinue}
          className="w-full py-3 px-6 bg-gold hover:bg-gold-light text-dark font-semibold rounded-xl transition-colors"
        >
          Generate Report Preview
        </button>
      </div>
    </div>
  );
};

export default ReportConfig;
