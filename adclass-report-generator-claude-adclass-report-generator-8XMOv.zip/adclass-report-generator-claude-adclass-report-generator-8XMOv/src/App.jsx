import { useState } from 'react';
import UploadScreen from './components/UploadScreen';
import ColumnMapping from './components/ColumnMapping';
import ReportConfig from './components/ReportConfig';
import ReportPreview from './components/ReportPreview';

const STEPS = {
  UPLOAD: 'upload',
  MAPPING: 'mapping',
  CONFIG: 'config',
  PREVIEW: 'preview',
};

function App() {
  const [currentStep, setCurrentStep] = useState(STEPS.UPLOAD);
  const [fileData, setFileData] = useState(null);
  const [columnMapping, setColumnMapping] = useState(null);
  const [reportConfig, setReportConfig] = useState(null);

  const handleFileUpload = (data) => {
    setFileData(data);
    setCurrentStep(STEPS.MAPPING);
  };

  const handleMappingComplete = (mapping) => {
    setColumnMapping(mapping);
    setCurrentStep(STEPS.CONFIG);
  };

  const handleConfigComplete = (config) => {
    setReportConfig(config);
    setCurrentStep(STEPS.PREVIEW);
  };

  const handleStartOver = () => {
    setFileData(null);
    setColumnMapping(null);
    setReportConfig(null);
    setCurrentStep(STEPS.UPLOAD);
  };

  const goBack = (step) => {
    setCurrentStep(step);
  };

  return (
    <div className="min-h-screen bg-dark">
      {currentStep === STEPS.UPLOAD && (
        <UploadScreen onFileUpload={handleFileUpload} />
      )}

      {currentStep === STEPS.MAPPING && fileData && (
        <ColumnMapping
          fileData={fileData}
          onMappingComplete={handleMappingComplete}
          onBack={() => goBack(STEPS.UPLOAD)}
        />
      )}

      {currentStep === STEPS.CONFIG && (
        <ReportConfig
          onConfigComplete={handleConfigComplete}
          onBack={() => goBack(STEPS.MAPPING)}
        />
      )}

      {currentStep === STEPS.PREVIEW && fileData && columnMapping && reportConfig && (
        <ReportPreview
          fileData={fileData}
          columnMapping={columnMapping}
          reportConfig={reportConfig}
          onBack={() => goBack(STEPS.CONFIG)}
          onStartOver={handleStartOver}
        />
      )}
    </div>
  );
}

export default App;
