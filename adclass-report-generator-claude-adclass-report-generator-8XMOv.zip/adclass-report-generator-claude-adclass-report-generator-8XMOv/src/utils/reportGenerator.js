import { getCPLTier, getTopPerformers, getNeedsOptimization, calculateTotals } from './fileParser';

const formatCurrency = (value) => {
  if (value === null || value === undefined) return 'N/A';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
};

const formatNumber = (value) => {
  if (value === null || value === undefined) return 'N/A';
  return new Intl.NumberFormat('en-US').format(Math.round(value));
};

const getTierColor = (tier) => {
  const colors = {
    excellent: '#22C55E',
    good: '#C9A227',
    average: '#F59E0B',
    poor: '#EF4444',
    unknown: '#6B7280',
  };
  return colors[tier] || colors.unknown;
};

const getStatusBadge = (status) => {
  if (!status) return '';
  const normalizedStatus = String(status).toLowerCase().trim();
  const isActive = ['active', 'running', 'enabled', 'live'].includes(normalizedStatus);
  const color = isActive ? '#22C55E' : '#6B7280';
  const text = isActive ? 'Active' : 'Inactive';
  return `<span style="display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 500; background: ${color}20; color: ${color}; text-transform: uppercase;">${text}</span>`;
};

export const generateReportHTML = (config) => {
  const {
    data,
    reportTitle,
    clientName,
    dateRange,
    thresholds,
    generatedDate,
  } = config;

  const totals = calculateTotals(data);
  const topPerformers = getTopPerformers(data, 5);
  const needsOptimization = getNeedsOptimization(data, 5);

  // Calculate max CPL for bar visualization
  const maxCPL = Math.max(...data.filter(d => d.cpl !== null).map(d => d.cpl), 1);

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${reportTitle} - ${clientName}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Montserrat:wght@500;600;700;800&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #0D0D0D;
      color: #FFFFFF;
      line-height: 1.5;
      min-height: 100vh;
    }

    h1, h2, h3, h4, h5, h6 {
      font-family: 'Montserrat', sans-serif;
    }

    .container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 40px 24px;
    }

    /* Header */
    .header {
      text-align: center;
      margin-bottom: 48px;
      padding-bottom: 32px;
      border-bottom: 1px solid #333;
    }

    .logo {
      font-family: 'Montserrat', sans-serif;
      font-size: 32px;
      font-weight: 800;
      color: #C9A227;
      margin-bottom: 24px;
      letter-spacing: 2px;
    }

    .logo span {
      color: #FFFFFF;
    }

    .report-title {
      font-size: 28px;
      font-weight: 700;
      color: #FFFFFF;
      margin-bottom: 8px;
    }

    .client-name {
      font-size: 18px;
      color: #C9A227;
      margin-bottom: 16px;
    }

    .date-info {
      font-size: 14px;
      color: #9CA3AF;
    }

    .date-info span {
      display: inline-block;
      margin: 0 8px;
    }

    /* KPI Cards */
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }

    .kpi-card {
      background: #1A1A1A;
      border-radius: 12px;
      padding: 24px;
      text-align: center;
    }

    .kpi-card.highlight {
      background: linear-gradient(135deg, #C9A227 0%, #A68420 100%);
    }

    .kpi-card.highlight .kpi-label {
      color: rgba(255, 255, 255, 0.9);
    }

    .kpi-card.highlight .kpi-value {
      color: #FFFFFF;
    }

    .kpi-label {
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9CA3AF;
      margin-bottom: 8px;
    }

    .kpi-value {
      font-family: 'Montserrat', sans-serif;
      font-size: 28px;
      font-weight: 700;
      color: #FFFFFF;
    }

    /* Summary Cards */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 24px;
      margin-bottom: 32px;
    }

    .summary-card {
      background: #1A1A1A;
      border-radius: 12px;
      padding: 24px;
    }

    .summary-card h3 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .summary-card h3.success { color: #22C55E; }
    .summary-card h3.warning { color: #F59E0B; }

    .summary-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 0;
      border-bottom: 1px solid #333;
    }

    .summary-item:last-child {
      border-bottom: none;
    }

    .summary-item-name {
      font-size: 14px;
      color: #E5E7EB;
      max-width: 60%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .summary-item-value {
      font-weight: 600;
      font-size: 14px;
    }

    /* Data Table */
    .table-section {
      background: #1A1A1A;
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 32px;
    }

    .table-header {
      padding: 20px 24px;
      border-bottom: 1px solid #333;
    }

    .table-header h3 {
      font-size: 18px;
      font-weight: 600;
    }

    .table-container {
      overflow-x: auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th {
      background: #252525;
      padding: 14px 16px;
      text-align: left;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9CA3AF;
      cursor: pointer;
      user-select: none;
      white-space: nowrap;
    }

    th:hover {
      background: #333;
      color: #C9A227;
    }

    th.sorted-asc::after { content: ' \\2191'; }
    th.sorted-desc::after { content: ' \\2193'; }

    td {
      padding: 14px 16px;
      border-bottom: 1px solid #252525;
      font-size: 14px;
    }

    tr:hover td {
      background: #252525;
    }

    .ad-name {
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .cpl-cell {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .cpl-value {
      font-weight: 600;
      min-width: 70px;
    }

    .cpl-bar-container {
      flex: 1;
      max-width: 100px;
      height: 6px;
      background: #333;
      border-radius: 3px;
      overflow: hidden;
    }

    .cpl-bar {
      height: 100%;
      border-radius: 3px;
      transition: width 0.3s ease;
    }

    .text-right {
      text-align: right;
    }

    /* Footer */
    .footer {
      text-align: center;
      padding-top: 32px;
      border-top: 1px solid #333;
      color: #6B7280;
      font-size: 14px;
    }

    .footer-logo {
      font-family: 'Montserrat', sans-serif;
      font-size: 18px;
      font-weight: 700;
      color: #C9A227;
      margin-bottom: 8px;
    }

    .footer-logo span {
      color: #9CA3AF;
    }

    /* Print Styles */
    @media print {
      body {
        background: white;
        color: #1A1A1A;
      }

      .kpi-card, .summary-card, .table-section {
        background: #F9FAFB;
        border: 1px solid #E5E7EB;
      }

      .kpi-card.highlight {
        background: #C9A227;
      }

      th {
        background: #E5E7EB;
      }

      td {
        border-color: #E5E7EB;
      }

      .cpl-bar-container {
        background: #E5E7EB;
      }
    }

    @media (max-width: 768px) {
      .container {
        padding: 24px 16px;
      }

      .kpi-value {
        font-size: 22px;
      }

      .summary-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <div class="logo">AD<span>CLASS</span></div>
      <h1 class="report-title">${escapeHtml(reportTitle)}</h1>
      <p class="client-name">${escapeHtml(clientName)}</p>
      <p class="date-info">
        <span>Report Period: ${escapeHtml(dateRange)}</span>
        <span>|</span>
        <span>Generated: ${escapeHtml(generatedDate)}</span>
      </p>
    </header>

    <!-- KPI Cards -->
    <div class="kpi-grid">
      <div class="kpi-card highlight">
        <div class="kpi-label">Blended CPL</div>
        <div class="kpi-value">${formatCurrency(totals.blendedCPL)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Total Spend</div>
        <div class="kpi-value">${formatCurrency(totals.spend)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Total Leads</div>
        <div class="kpi-value">${formatNumber(totals.leads)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Total Reach</div>
        <div class="kpi-value">${formatNumber(totals.reach)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Total Impressions</div>
        <div class="kpi-value">${formatNumber(totals.impressions)}</div>
      </div>
    </div>

    <!-- Performance Summary -->
    <div class="summary-grid">
      <div class="summary-card">
        <h3 class="success">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
            <polyline points="22 4 12 14.01 9 11.01"/>
          </svg>
          Top Performers
        </h3>
        ${topPerformers.map(ad => `
          <div class="summary-item">
            <span class="summary-item-name" title="${escapeHtml(ad.adName)}">${escapeHtml(ad.adName)}</span>
            <span class="summary-item-value" style="color: ${getTierColor(getCPLTier(ad.cpl, thresholds))}">${formatCurrency(ad.cpl)}</span>
          </div>
        `).join('')}
        ${topPerformers.length === 0 ? '<p style="color: #6B7280; font-size: 14px;">No data available</p>' : ''}
      </div>

      <div class="summary-card">
        <h3 class="warning">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
          </svg>
          Needs Optimization
        </h3>
        ${needsOptimization.map(ad => `
          <div class="summary-item">
            <span class="summary-item-name" title="${escapeHtml(ad.adName)}">${escapeHtml(ad.adName)}</span>
            <span class="summary-item-value" style="color: ${getTierColor(getCPLTier(ad.cpl, thresholds))}">${formatCurrency(ad.cpl)}</span>
          </div>
        `).join('')}
        ${needsOptimization.length === 0 ? '<p style="color: #6B7280; font-size: 14px;">No data available</p>' : ''}
      </div>
    </div>

    <!-- Data Table -->
    <div class="table-section">
      <div class="table-header">
        <h3>All Ad Performance</h3>
      </div>
      <div class="table-container">
        <table id="dataTable">
          <thead>
            <tr>
              <th data-sort="adName">Ad Name</th>
              <th data-sort="spend" class="text-right">Spend</th>
              <th data-sort="leads" class="text-right">Leads</th>
              <th data-sort="cpl">CPL</th>
              <th data-sort="reach" class="text-right">Reach</th>
              <th data-sort="impressions" class="text-right">Impressions</th>
              <th data-sort="status">Status</th>
            </tr>
          </thead>
          <tbody>
            ${data.map(row => {
              const tier = getCPLTier(row.cpl, thresholds);
              const barWidth = row.cpl !== null ? Math.min((row.cpl / maxCPL) * 100, 100) : 0;
              return `
                <tr>
                  <td class="ad-name" title="${escapeHtml(row.adName)}">${escapeHtml(row.adName)}</td>
                  <td class="text-right">${formatCurrency(row.spend)}</td>
                  <td class="text-right">${formatNumber(row.leads)}</td>
                  <td>
                    <div class="cpl-cell">
                      <span class="cpl-value" style="color: ${getTierColor(tier)}">${formatCurrency(row.cpl)}</span>
                      <div class="cpl-bar-container">
                        <div class="cpl-bar" style="width: ${barWidth}%; background: ${getTierColor(tier)}"></div>
                      </div>
                    </div>
                  </td>
                  <td class="text-right">${formatNumber(row.reach)}</td>
                  <td class="text-right">${formatNumber(row.impressions)}</td>
                  <td>${getStatusBadge(row.status)}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-logo">AD<span>CLASS</span></div>
      <p>Report prepared by AdClass | info@adclass.com</p>
    </footer>
  </div>

  <script>
    // Table sorting functionality
    document.addEventListener('DOMContentLoaded', function() {
      const table = document.getElementById('dataTable');
      const headers = table.querySelectorAll('th[data-sort]');
      let currentSort = { column: null, direction: 'asc' };

      const data = ${JSON.stringify(data)};

      headers.forEach(header => {
        header.addEventListener('click', function() {
          const column = this.dataset.sort;
          const direction = currentSort.column === column && currentSort.direction === 'asc' ? 'desc' : 'asc';

          // Update sort indicators
          headers.forEach(h => h.classList.remove('sorted-asc', 'sorted-desc'));
          this.classList.add(direction === 'asc' ? 'sorted-asc' : 'sorted-desc');

          // Sort data
          const sorted = [...data].sort((a, b) => {
            let aVal = a[column];
            let bVal = b[column];

            if (aVal === null || aVal === undefined) aVal = direction === 'asc' ? Infinity : -Infinity;
            if (bVal === null || bVal === undefined) bVal = direction === 'asc' ? Infinity : -Infinity;

            if (typeof aVal === 'string') {
              return direction === 'asc'
                ? aVal.localeCompare(bVal)
                : bVal.localeCompare(aVal);
            }

            return direction === 'asc' ? aVal - bVal : bVal - aVal;
          });

          currentSort = { column, direction };
          renderTable(sorted);
        });
      });

      function renderTable(sortedData) {
        const tbody = table.querySelector('tbody');
        const thresholds = ${JSON.stringify(thresholds)};
        const maxCPL = Math.max(...sortedData.filter(d => d.cpl !== null).map(d => d.cpl), 1);

        tbody.innerHTML = sortedData.map(row => {
          const tier = getCPLTier(row.cpl, thresholds);
          const barWidth = row.cpl !== null ? Math.min((row.cpl / maxCPL) * 100, 100) : 0;
          return \`
            <tr>
              <td class="ad-name" title="\${escapeHtml(row.adName)}">\${escapeHtml(row.adName)}</td>
              <td class="text-right">\${formatCurrency(row.spend)}</td>
              <td class="text-right">\${formatNumber(row.leads)}</td>
              <td>
                <div class="cpl-cell">
                  <span class="cpl-value" style="color: \${getTierColor(tier)}">\${formatCurrency(row.cpl)}</span>
                  <div class="cpl-bar-container">
                    <div class="cpl-bar" style="width: \${barWidth}%; background: \${getTierColor(tier)}"></div>
                  </div>
                </div>
              </td>
              <td class="text-right">\${formatNumber(row.reach)}</td>
              <td class="text-right">\${formatNumber(row.impressions)}</td>
              <td>\${getStatusBadge(row.status)}</td>
            </tr>
          \`;
        }).join('');
      }

      function getCPLTier(cpl, thresholds) {
        if (cpl === null || cpl === undefined) return 'unknown';
        if (cpl < thresholds.excellent) return 'excellent';
        if (cpl < thresholds.good) return 'good';
        if (cpl < thresholds.average) return 'average';
        return 'poor';
      }

      function getTierColor(tier) {
        const colors = {
          excellent: '#22C55E',
          good: '#C9A227',
          average: '#F59E0B',
          poor: '#EF4444',
          unknown: '#6B7280',
        };
        return colors[tier] || colors.unknown;
      }

      function formatCurrency(value) {
        if (value === null || value === undefined) return 'N/A';
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        }).format(value);
      }

      function formatNumber(value) {
        if (value === null || value === undefined) return 'N/A';
        return new Intl.NumberFormat('en-US').format(Math.round(value));
      }

      function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
      }

      function getStatusBadge(status) {
        if (!status) return '';
        const normalizedStatus = String(status).toLowerCase().trim();
        const isActive = ['active', 'running', 'enabled', 'live'].includes(normalizedStatus);
        const color = isActive ? '#22C55E' : '#6B7280';
        const text = isActive ? 'Active' : 'Inactive';
        return \`<span style="display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 500; background: \${color}20; color: \${color}; text-transform: uppercase;">\${text}</span>\`;
      }
    });
  </script>
</body>
</html>`;

  return html;
};

function escapeHtml(text) {
  if (!text) return '';
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  };
  return String(text).replace(/[&<>"']/g, m => map[m]);
}

export const downloadReport = (html, clientName, dateRange) => {
  const sanitizedClientName = clientName.replace(/[^a-zA-Z0-9]/g, '_');
  const sanitizedDateRange = dateRange.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `${sanitizedClientName}_Ad_Report_${sanitizedDateRange}.html`;

  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
