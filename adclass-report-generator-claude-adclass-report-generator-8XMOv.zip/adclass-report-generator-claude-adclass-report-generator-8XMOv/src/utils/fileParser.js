import Papa from 'papaparse';
import * as XLSX from 'xlsx';

export const parseFile = (file) => {
  return new Promise((resolve, reject) => {
    const fileExtension = file.name.split('.').pop().toLowerCase();

    if (fileExtension === 'csv') {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          resolve({
            data: results.data,
            columns: results.meta.fields || [],
            rowCount: results.data.length,
            errors: results.errors,
          });
        },
        error: (error) => {
          reject(error);
        },
      });
    } else if (['xlsx', 'xls'].includes(fileExtension)) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const workbook = XLSX.read(e.target.result, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

          if (jsonData.length === 0) {
            resolve({ data: [], columns: [], rowCount: 0, errors: [] });
            return;
          }

          const headers = jsonData[0].map(h => String(h || '').trim());
          const data = jsonData.slice(1).map((row) => {
            const obj = {};
            headers.forEach((header, index) => {
              obj[header] = row[index] !== undefined ? row[index] : '';
            });
            return obj;
          }).filter(row => Object.values(row).some(v => v !== ''));

          resolve({
            data,
            columns: headers.filter(h => h),
            rowCount: data.length,
            errors: [],
          });
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsArrayBuffer(file);
    } else {
      reject(new Error('Unsupported file format. Please use CSV, XLSX, or XLS files.'));
    }
  });
};

// Common column name variations for auto-detection
const columnMappings = {
  adName: [
    'ad name', 'ad_name', 'adname', 'name', 'ad', 'creative name',
    'creative_name', 'campaign name', 'ad title'
  ],
  spend: [
    'amount spent', 'amount_spent', 'spend', 'cost', 'amount spent (usd)',
    'spend (usd)', 'total spend', 'ad spend', 'amount'
  ],
  leads: [
    'leads', 'lead', 'conversions', 'results', 'total leads',
    'lead count', 'num_leads', 'leads (all)'
  ],
  cpl: [
    'cost per lead', 'cost_per_lead', 'cpl', 'cost per lead (usd)',
    'cost per result', 'cost/lead', 'cpa', 'cost per action'
  ],
  reach: [
    'reach', 'people reached', 'unique reach', 'total reach'
  ],
  impressions: [
    'impressions', 'imps', 'total impressions', 'impression', 'views'
  ],
  status: [
    'ad delivery', 'status', 'delivery status', 'ad status',
    'campaign status', 'state', 'delivery'
  ],
};

export const autoDetectColumns = (columns) => {
  const mapping = {
    adName: null,
    spend: null,
    leads: null,
    cpl: null,
    reach: null,
    impressions: null,
    status: null,
  };

  const normalizedColumns = columns.map(col => col.toLowerCase().trim());

  Object.entries(columnMappings).forEach(([field, variations]) => {
    for (const col of columns) {
      const normalizedCol = col.toLowerCase().trim();
      if (variations.includes(normalizedCol)) {
        mapping[field] = col;
        break;
      }
    }
  });

  return mapping;
};

export const processData = (rawData, columnMapping) => {
  return rawData.map((row, index) => {
    const getValue = (field) => {
      const colName = columnMapping[field];
      if (!colName) return null;
      return row[colName];
    };

    const parseNumber = (value) => {
      if (value === null || value === undefined || value === '') return null;
      if (typeof value === 'number') return value;
      // Remove currency symbols, commas, and parse
      const cleaned = String(value).replace(/[$,]/g, '').trim();
      const num = parseFloat(cleaned);
      return isNaN(num) ? null : num;
    };

    const spend = parseNumber(getValue('spend'));
    const leads = parseNumber(getValue('leads'));
    let cpl = parseNumber(getValue('cpl'));

    // Calculate CPL if not provided but spend and leads are available
    if (cpl === null && spend !== null && leads !== null && leads > 0) {
      cpl = spend / leads;
    }

    return {
      id: index,
      adName: getValue('adName') || 'Unnamed Ad',
      spend: spend,
      leads: leads,
      cpl: cpl,
      reach: parseNumber(getValue('reach')),
      impressions: parseNumber(getValue('impressions')),
      status: getValue('status') || null,
    };
  }).filter(row => row.adName && (row.spend !== null || row.leads !== null));
};

export const calculateTotals = (processedData) => {
  const totals = processedData.reduce(
    (acc, row) => {
      acc.spend += row.spend || 0;
      acc.leads += row.leads || 0;
      acc.reach += row.reach || 0;
      acc.impressions += row.impressions || 0;
      return acc;
    },
    { spend: 0, leads: 0, reach: 0, impressions: 0 }
  );

  totals.blendedCPL = totals.leads > 0 ? totals.spend / totals.leads : 0;

  return totals;
};

export const getCPLTier = (cpl, thresholds) => {
  if (cpl === null || cpl === undefined) return 'unknown';
  if (cpl < thresholds.excellent) return 'excellent';
  if (cpl < thresholds.good) return 'good';
  if (cpl < thresholds.average) return 'average';
  return 'poor';
};

export const getTopPerformers = (data, count = 5) => {
  return [...data]
    .filter(row => row.cpl !== null && row.cpl > 0)
    .sort((a, b) => a.cpl - b.cpl)
    .slice(0, count);
};

export const getNeedsOptimization = (data, count = 5) => {
  return [...data]
    .filter(row => row.cpl !== null && row.cpl > 0)
    .sort((a, b) => b.cpl - a.cpl)
    .slice(0, count);
};
